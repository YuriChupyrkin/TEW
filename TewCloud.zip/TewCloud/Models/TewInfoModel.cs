﻿namespace TewCloud.Models
{
  public class TewInfoModel
  {
    public int Users { get; set; }
    public int Words { get; set; }
  }
}